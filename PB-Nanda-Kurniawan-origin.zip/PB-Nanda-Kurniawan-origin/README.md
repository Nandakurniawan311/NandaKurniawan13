Sebelumnya kita sudah mempelajari bagaimana menghubungkan Aplikasi dengan Firebase, maka ada beberapa tugas yang mesti diselesaikan

Tugas:
1. Mensolve Code untuk SignUp agar dapat masuk ke Firebase
2. Membuat halaman Home secara sederhana dengan menggunakan Cardview dan NestedScrollview
3. Membuat halaman Profile yang menampilkan data user
4. Jika sudah, pastikan Code di Push ke Github dengan nama Repository "PB-nama mahasiswa"

Pada tugas sebelum nya, kalian sudah berhasil membuat beberapa tampilan dengan menggunakan Cardview dan NestedScrollview, maka ada beberapa tugas yang akan abang tambahkan sebelum kita UTS:

1. Membuat Minimal 2-3 menu utama yang nanti akan ada pada tampilan Home (menu utama nya bebas, namun dapat menginputkan dan menampilkan data, contoh nya pencatatan keuangan ataupun memo)
2. Buatlah tampilan yang menarik, kemudian buatlah tampilan NavigationBar (Disarankan terdapat 3 menu, Home, Profile, Pengaturan)
3. Selamat mengerjakan
